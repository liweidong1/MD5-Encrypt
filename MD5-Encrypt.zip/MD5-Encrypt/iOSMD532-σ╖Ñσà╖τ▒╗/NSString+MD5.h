//
//  NSString+MD5.h
//  Spread
//
//  Created by sillen on 17/4/26.
//  Copyright © 2016年 邱sillen伟. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MD5)
/** 将字符串经MD5加密 */
+(NSString *)MD5:(NSString *)str;
@end
