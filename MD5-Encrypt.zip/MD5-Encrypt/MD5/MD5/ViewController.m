//
//  ViewController.m
//  MD5
//
//  Created by sillen on 17/4/26.
//  Copyright © 2016年 sillenLi@163.com. All rights reserved.
//

#import "ViewController.h"
#import "NSString+LSMD5.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *orginStr = @"这是原始字符串,下边是MD5加密之后的字符串";
    NSString *md5Str = [NSString md5:orginStr];
    NSLog(@"%@", orginStr);
    NSLog(@"%@", md5Str);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
