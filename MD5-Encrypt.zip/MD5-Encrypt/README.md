MD5

> iOS下MD5加密算法的OC封装，采用Category方式为NSSting添加了字符串MD5加密方法。


