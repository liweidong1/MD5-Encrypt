//
//  main.m
//  MD5
//
//  Created by sillen on 17/4/26.
//  Copyright © 2016年 sillenLi@163.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
